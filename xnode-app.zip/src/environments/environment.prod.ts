export const environment = {
    production: false,
    apiUrl: 'https://prod-navi.azurewebsites.net/',
    targetUrl: 'https://prod-xnode.azurewebsites.net/',
    workFlowApiUrl: 'https://prod-xnode-xflows.azurewebsites.net/',
    authApiUrl: 'https://prod-xnode-auth-api.azurewebsites.net/',
    productId: 'c898da18-be1e-4d32-957b-e544227e0e47'
}
