export const environment = {
    production: false,
    apiUrl: 'https://qa-navi.azurewebsites.net/',
    targetUrl: 'https://qa-xnode.azurewebsites.net/',
    workFlowApiUrl: 'https://qa-xnode-xflows.azurewebsites.net/',
    authApiUrl: 'https://qa-xnode-auth-api.azurewebsites.net/',
    productId: 'c898da18-be1e-4d32-957b-e544227e0e47',
}
