export const environment = {
    production: false,
    apiUrl: 'https://demo-navi.azurewebsites.net/',
    targetUrl: 'https://demo-xnode.azurewebsites.net/',
    workFlowApiUrl: 'https://demo-xnode-xflows.azurewebsites.net/',
    authApiUrl: 'https://demo-xnode-auth-api.azurewebsites.net/',
    productId: 'c898da18-be1e-4d32-957b-e544227e0e47',
}
