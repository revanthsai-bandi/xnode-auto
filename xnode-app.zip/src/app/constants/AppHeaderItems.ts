export const HeaderItems = [
    {
        label: 'File'
    },
    {
        label: 'Edit'
    },
    {
        label: 'View'
    },
    {
        label: 'Project'
    },
    {
        label: 'Run'
    },
    {
        label: 'Version Control'
    },
    {
        label: 'Language'
    },
    {
        label: 'Help'
    }
]