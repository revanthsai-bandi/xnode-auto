export const AppSideMenuItems = [
    {
        label: 'Overview',
        icon: './assets/overview.svg'
    },
    {
        label: 'Usecase',
        icon: './assets/overview.svg'
    },
    {
        label: 'Design',
        icon: './assets/design.svg'
    },
    {
        label: 'Config',
        icon: './assets/config.svg'
    },
    {
        label: 'Publish',
        icon: './assets/publish.svg'
    }
]