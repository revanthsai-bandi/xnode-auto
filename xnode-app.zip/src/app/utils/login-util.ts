export const Emails = [
    {
        email: 'admin@xnode.ai',
        password: 'admin@123'
    },
    {
        email: 'demo@xnode.ai',
        password: 'demo@123'
    },
    {
        email: 'test@xnode.ai',
        password: 'test@123'
    },
    {
        email: 'dev@xnode.ai',
        password: 'dev@123'
    }
]