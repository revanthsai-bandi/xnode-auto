import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-expenses-pie-chart',
  templateUrl: './all-expenses-pie-chart.component.html',
  styleUrls: ['./all-expenses-pie-chart.component.scss']
})
export class AllExpensesPieChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
